package com.example.prova_camilli_09

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    /*
    * CAMILLI JOANNES FERREIRA ASSIS
    * MATRÍCULA: 22000550
    * N° DE CHAMADA: 9
    */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var BotaoCaucular = findViewById<Button>(R.id.buttonCaucular);

        var Alerta1: String = "Preencha todos os campos corretamente!"
        var Alerta2: String = "Atenção! Você deve digitar no campo ‘Meses trabalhados’ os valores entre 1 e 12."
        var Vazio: String = ""
        BotaoCaucular?.setOnClickListener {
            var Salario = findViewById<EditText>(R.id.editTextSalaraio).text.toString();
            var Meses = findViewById<EditText>(R.id.editTextMeses).text.toString();

        if (Salario.isEmpty() || Meses.isEmpty()){
            findViewById<TextView>(R.id.Alerta).setText(Alerta1)
        }else{
            if (Meses.toInt()>0 && Meses.toInt()<=12){
                var Resultado: Float = (Salario.toFloat()*Meses.toFloat())/12
                var FraseFinal:String = "O valor a receber deverá ser: R$" + Resultado
                findViewById<TextView>(R.id.textView4).setText(FraseFinal)
                findViewById<TextView>(R.id.Alerta).setText(Vazio)
            }else{
                findViewById<TextView>(R.id.Alerta).setText(Alerta2)
            }

        }

        }

    }



}